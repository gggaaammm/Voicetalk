import os
import sys
import time
import pandas as pd


# Suppress as many warnings as possible
# this code hide the warning meesage
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
from tensorflow.python.util import deprecation
deprecation._PRINT_DEPRECATION_WARNINGS = False
import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

from ckiptagger import data_utils, construct_dictionary, WS, POS, NER


start = time.time()
ws = WS("./data", disable_cuda=False)
pos = POS("./data", disable_cuda=False)
ner = NER("./data", disable_cuda=False)
end = time.time()
print("loading time: ", end-start)


from flask import Flask, render_template, request
app = Flask(__name__)
@app.route('/',methods=['POST','GET'])
def index():
     # Load model with GPU
    
    
    end = time.time()
    if(request.method == 'POST'):
        text = request.values['user']
        print(text)
        textParse(text,ws,pos,ner)
    return render_template("index.html")




def dictionaryLookup(word,A_dict, D_dict, F_dict, V_dict):
    key = 4
    if word in A_dict:
        key = 0
    if word in D_dict:
        key = 1
    if word in F_dict:
        key = 2
    if word in V_dict:
        key = 3
    return key
    
def num_there(s):
    return any(i.isdigit() for i in s)
    
def mappingToken(wordset): #mapping token should return an array of A/D/F/V
    token = [0,0,0,0,0]
    j=0
    path_A_dict = r"dict/A.txt"
    A_dict = pd.read_csv(path_A_dict, sep="\n", header=None)
    # 存到list
    A_dict.columns = ['A']
    A_list = list(A_dict['A'])
    
    path_D_dict = r"dict/D.txt"
    D_dict = pd.read_csv(path_D_dict, sep="\n", header=None)
    # 存到list
    D_dict.columns = ['D']
    D_list = list(D_dict['D'])
    
    path_F_dict = r"dict/F.txt"
    F_dict = pd.read_csv(path_F_dict, sep="\n", header=None)
    # 存到list
    F_dict.columns = ['F']
    F_list = list(F_dict['F'])
    
    path_V_dict = r"dict/V.txt"
    V_dict = pd.read_csv(path_V_dict, sep="\n", header=None)
    # 存到list
    V_dict.columns = ['V']
    V_list = list(V_dict['V'])
    
    while(j<len(wordset)):
        print(wordset[j])
        get_token = dictionaryLookup(wordset[j],A_list,D_list, F_list,V_list)
        print("token: ",get_token)
        token[get_token] = wordset[j]
        if(num_there(wordset[j])): #check if number exist in word
            get_token = 3
            token[3] = wordset[j]
        j=j+1
    
    return token
        
        




def textParse(text,ws,pos,ner):
    # Download data
    # data_utils.download_data("./")
    
    # Load model without GPU
    #ws = WS("./data")
    #pos = POS("./data")
    #ner = NER("./data")
    
    
    # 用讀CSV的方式讀取前面匯出的txt
    path_D_dict = r"dict/D.txt"
    df_ner_dict = pd.read_csv(path_D_dict, sep="\n", header=None)
    # 存到list
    df_ner_dict.columns = ['NER']
    list_ner_dict = list(df_ner_dict['NER'])
    # 將list轉成dict型態，這邊每個權重都設為1
    dict_for_CKIP = dict((el,1) for el in list_ner_dict)
    # Create custom dictionary
#     word_to_weight = {
#         u"大同電扇": 1,
#         u"奇美電扇": 1,
#         u"大同空氣清淨機": 1,
#         "大同冷氣":1,
#         "窗簾一":1
#     }
    dictionary = construct_dictionary(dict_for_CKIP)
    print(dictionary)
    
    # Run WS-POS-NER pipeline
    sentence_list = [
        text,
        "把奇美電扇的風速設定成強風",
        "打開窗簾一",
    ]
    # word_sentence_list = ws(sentence_list)
    #word_sentence_list = ws(sentence_list, sentence_segmentation=True)
    start = time.time()
    word_sentence_list = ws(sentence_list, recommend_dictionary=dictionary)
#     word_sentence_list = ws(sentence_list, coerce_dictionary=dictionary)
    pos_sentence_list = pos(word_sentence_list)
    entity_sentence_list = ner(word_sentence_list, pos_sentence_list)
    end  = time.time()
    
    print("execution time: ", end-start)
    
    # Release model
    del ws
    del pos
    del ner
    
    # Show results
    def print_word_pos_sentence(word_sentence, pos_sentence):
        assert len(word_sentence) == len(pos_sentence)
        tokenlist = mappingToken(word_sentence)
        print("token list: ", tokenlist)
            
#         for word, pos in zip(word_sentence, pos_sentence):
#             print(f"{word}({pos})", end="\u3000")
#             print("sentence:", word_sentence)
#             print("type:", type(word_sentence))
#         return
    
    for i, sentence in enumerate(sentence_list):
        print()
#         print("sentence list")
        print(f"'{sentence}'")
        print_word_pos_sentence(word_sentence_list[i],  pos_sentence_list[i])
        for entity in sorted(entity_sentence_list[i]):
            print(entity)
            
    return
    

if __name__ == "__main__":
    app.run(host='0.0.0.0',debug=True, port=19453)
    